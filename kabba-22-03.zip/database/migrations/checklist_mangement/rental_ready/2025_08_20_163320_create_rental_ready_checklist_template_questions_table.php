<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('rental_ready_checklist_template_questions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('template_id')
                  ->constrained('rental_ready_checklist_templates')
                  ->onDelete('cascade');
            $table->foreignId('question_id')
                  ->constrained('rental_ready_checklist_questions') // assumes you already have questions table
                  ->onDelete('cascade');
            $table->integer('index_number')->default(0);
            $table->string('unique_id')->unique();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('rental_ready_checklist_template_questions');
    }
};
